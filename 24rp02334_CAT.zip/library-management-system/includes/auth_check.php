<?php
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to access this page.";
    header("Location: ../auth/login.php");
    exit();
}
?>