    </main>

    <!-- Footer -->
    <footer class="bg-dark text-light mt-5">
        <div class="container py-4">
            <div class="row">
                <div class="col-md-6">
                    <h5>RP Karongi Library</h5>
                    <p>Digital Library Management System</p>
                    <p>Email: library@karongi.rp.ac.rw</p>
                    <p>Phone: +250 788 123 456</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="/library-management-system/index.php" class="text-light">Home</a></li>
                        <li><a href="/library-management-system/books/index.php" class="text-light">Books</a></li>
                        <li><a href="/library-management-system/contact.php" class="text-light">Contact</a></li>
                    </ul>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; <?php echo date('Y'); ?> RP Karongi Library. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Local Bootstrap JS -->
    <script src="/library-management-system/assets/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="/library-management-system/assets/js/script.js"></script>
</body>
</html>