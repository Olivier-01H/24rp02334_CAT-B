<?php include 'includes/header.php'; ?>

<!-- Hero Section -->
<section class="hero-section text-center">
    <div class="container">
        <h1 class="display-4 fw-bold">Welcome to RP Karongi Library</h1>
        <p class="lead">Discover, Learn, and Grow with Our Digital Library Collection</p>
        <?php if (!isset($_SESSION['user_id'])): ?>
            <div class="mt-4">
                <a href="auth/register.php" class="btn btn-light btn-lg me-3">Get Started</a>
                <a href="auth/login.php" class="btn btn-outline-light btn-lg">Login</a>
            </div>
        <?php else: ?>
            <div class="mt-4">
                <a href="books/index.php" class="btn btn-light btn-lg me-3">Browse Books</a>
                <a href="dashboard.php" class="btn btn-outline-light btn-lg">My Dashboard</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Features Section -->
<section class="container mb-5">
    <div class="row text-center">
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="book-cover mb-3">📚</div>
                    <h5 class="card-title">Extensive Collection</h5>
                    <p class="card-text">Access thousands of books across various categories and disciplines.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="book-cover mb-3">⚡</div>
                    <h5 class="card-title">Easy Borrowing</h5>
                    <p class="card-text">Simple and quick book borrowing process with online availability check.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="book-cover mb-3">📱</div>
                    <h5 class="card-title">Digital Management</h5>
                    <p class="card-text">Manage your borrowed books and track due dates from your dashboard.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistics Section -->
<section class="bg-light py-5">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-3">
                <h3 class="text-primary">5000+</h3>
                <p>Books Available</p>
            </div>
            <div class="col-md-3">
                <h3 class="text-success">1000+</h3>
                <p>Active Students</p>
            </div>
            <div class="col-md-3">
                <h3 class="text-warning">50+</h3>
                <p>Book Categories</p>
            </div>
            <div class="col-md-3">
                <h3 class="text-info">24/7</h3>
                <p>Online Access</p>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>