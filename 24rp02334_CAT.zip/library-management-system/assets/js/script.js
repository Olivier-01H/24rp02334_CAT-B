 // Bootstrap custom validation
(function () {
  'use strict'
  var forms = document.querySelectorAll('.needs-validation')
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })
})()

// Auto-dismiss Bootstrap alerts after 5s
window.addEventListener('load', function() {
  setTimeout(function() {
    document.querySelectorAll('.alert').forEach(function(el){
      var alert = new bootstrap.Alert(el)
      alert.close()
    })
  }, 5000)
})

