 <?php
include '../includes/config.php';
include '../includes/auth_check.php';
include '../includes/admin_check.php';
include '../includes/functions.php';
?>
<?php include '../includes/header.php'; ?>

<div class="row">
  <div class="col-12">
    <h2>Admin Dashboard</h2>
    <p class="lead">Quick links</p>
    <a class="btn btn-primary me-2" href="/library-management-system/admin/books.php">Manage Books</a>
    <a class="btn btn-outline-primary" href="/library-management-system/admin/users.php">Manage Users</a>
  </div>
</div>

<?php include '../includes/footer.php'; ?>

