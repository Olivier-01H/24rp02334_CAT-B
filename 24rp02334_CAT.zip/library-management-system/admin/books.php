 <?php
include '../includes/config.php';
include '../includes/auth_check.php';
include '../includes/admin_check.php';
include '../includes/functions.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;
    $action = $_POST['action'] ?? 'add';

    if ($title === '' || $author === '' || $category === '') {
        $error = 'All fields are required.';
    } else {
        try {
            if ($action === 'add') {
                $stmt = $db->prepare('INSERT INTO books (title, author, category, availability_status) VALUES (:title, :author, :category, "available")');
                $stmt->execute([':title'=>$title, ':author'=>$author, ':category'=>$category]);
                $success = 'Book added successfully.';
            } elseif ($action === 'edit' && $book_id > 0) {
                $stmt = $db->prepare('UPDATE books SET title = :title, author = :author, category = :category WHERE book_id = :id');
                $stmt->execute([':title'=>$title, ':author'=>$author, ':category'=>$category, ':id'=>$book_id]);
                $success = 'Book updated successfully.';
            }
        } catch (PDOException $e) {
            $error = 'Operation failed: ' . $e->getMessage();
        }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    try {
        $stmt = $db->prepare('DELETE FROM books WHERE book_id = :id');
        $stmt->execute([':id'=>$id]);
        $success = 'Book deleted.';
    } catch (PDOException $e) {
        $error = 'Delete failed: ' . $e->getMessage();
    }
}

$editBook = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $db->prepare('SELECT * FROM books WHERE book_id = :id');
    $stmt->execute([':id'=>$id]);
    $editBook = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

$books = [];
try {
    $books = $db->query('SELECT * FROM books ORDER BY created_at DESC')->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>

<?php include '../includes/header.php'; ?>

<div class="row mb-3">
    <div class="col"><h2>Manage Books</h2></div>
    <div class="col-auto"><a class="btn btn-secondary" href="/library-management-system/books/index.php">View Catalog</a></div>
    <div class="col-12 mt-2">
        <?php echo display_message($error, 'danger'); ?>
        <?php echo display_message($success, 'success'); ?>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header"><strong><?php echo $editBook? 'Edit Book' : 'Add New Book'; ?></strong></div>
    <div class="card-body">
        <form method="post" class="row g-3 needs-validation" novalidate>
            <input type="hidden" name="action" value="<?php echo $editBook? 'edit':'add'; ?>">
            <?php if ($editBook): ?>
                <input type="hidden" name="book_id" value="<?php echo (int)$editBook['book_id']; ?>">
            <?php endif; ?>
            <div class="col-md-4">
                <label class="form-label">Title</label>
                <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($editBook['title'] ?? ''); ?>" required>
                <div class="invalid-feedback">Title is required.</div>
            </div>
            <div class="col-md-4">
                <label class="form-label">Author</label>
                <input type="text" name="author" class="form-control" value="<?php echo htmlspecialchars($editBook['author'] ?? ''); ?>" required>
                <div class="invalid-feedback">Author is required.</div>
            </div>
            <div class="col-md-4">
                <label class="form-label">Category</label>
                <input type="text" name="category" class="form-control" value="<?php echo htmlspecialchars($editBook['category'] ?? ''); ?>" required>
                <div class="invalid-feedback">Category is required.</div>
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary"><?php echo $editBook? 'Update' : 'Add Book'; ?></button>
                <?php if ($editBook): ?>
                    <a href="books.php" class="btn btn-outline-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header"><strong>Books List</strong></div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped align-middle">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($books as $b): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($b['title']); ?></td>
                            <td><?php echo htmlspecialchars($b['author']); ?></td>
                            <td><?php echo htmlspecialchars($b['category']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $b['availability_status']==='available'?'success':'secondary'; ?>"><?php echo htmlspecialchars($b['availability_status']); ?></span>
                            </td>
                            <td>
                                <a class="btn btn-sm btn-outline-primary" href="?edit=<?php echo (int)$b['book_id']; ?>">Edit</a>
                                <a class="btn btn-sm btn-outline-danger" href="?delete=<?php echo (int)$b['book_id']; ?>" onclick="return confirm('Delete this book?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

