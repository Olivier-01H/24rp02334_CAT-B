 <?php
include '../includes/config.php';
include '../includes/auth_check.php';
include '../includes/admin_check.php';

$users = [];
try {
    $stmt = $db->query('SELECT user_id, username, email, student_id, role, created_at FROM users ORDER BY created_at DESC');
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<?php include '../includes/header.php'; ?>

<div class="row mb-3">
  <div class="col"><h2>Users</h2></div>
</div>

<div class="card">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Student ID</th>
            <th>Role</th>
            <th>Joined</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $u): ?>
            <tr>
              <td><?php echo htmlspecialchars($u['username']); ?></td>
              <td><?php echo htmlspecialchars($u['email']); ?></td>
              <td><?php echo htmlspecialchars($u['student_id']); ?></td>
              <td><span class="badge bg-<?php echo $u['role']==='admin'?'primary':'secondary'; ?>"><?php echo htmlspecialchars($u['role']); ?></span></td>
              <td><?php echo htmlspecialchars($u['created_at']); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>

