<?php include 'includes/header.php'; ?>

<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header"><h4 class="mb-0">Contact Us</h4></div>
      <div class="card-body">
        <p class="text-muted">Have a question? Send us a message.</p>
        <form class="needs-validation" novalidate>
          <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" required>
            <div class="invalid-feedback">Name is required.</div>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" required>
            <div class="invalid-feedback">Valid email is required.</div>
          </div>
          <div class="mb-3">
            <label class="form-label">Message</label>
            <textarea class="form-control" rows="4" required></textarea>
            <div class="invalid-feedback">Message is required.</div>
          </div>
          <button class="btn btn-primary" type="submit">Send Message</button>
        </form>
        <hr>
        <p class="mb-1"><strong>Email:</strong> library@karongi.rp.ac.rw</p>
        <p class="mb-0"><strong>Phone:</strong> +250 788 123 456</p>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

