<?php
include '../includes/config.php';
include '../includes/functions.php';

if (isset($_SESSION['user_id'])) {
    header("Location: ../dashboard.php");
    exit();
}

$username = '';
$error = '';

if ($_POST) {
    $username = sanitize_input($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password.";
    } else {
        try {
            $query = "SELECT user_id, username, email, password, role, student_id FROM users WHERE username = :username OR email = :username";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->execute();

            if ($stmt->rowCount() == 1) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['student_id'] = $user['student_id'];
                    
                    $_SESSION['success'] = "Welcome back, " . $user['username'] . "!";
                    header("Location: ../dashboard.php");
                    exit();
                } else {
                    $error = "Invalid password.";
                }
            } else {
                $error = "No account found with that username/email.";
            }
        } catch (PDOException $exception) {
            $error = "Login failed: " . $exception->getMessage();
        }
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0">Student Login</h4>
            </div>
            <div class="card-body">
                <?php 
                if (isset($_SESSION['success'])) {
                    echo display_message($_SESSION['success'], 'success');
                    unset($_SESSION['success']);
                }
                echo display_message($error, 'danger'); 
                ?>
                
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username or Email</label>
                        <input type="text" class="form-control" id="username" name="username" 
                               value="<?php echo htmlspecialchars($username); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>

                <div class="text-center mt-3">
                    <p>Don't have an account? <a href="register.php">Register here</a></p>
                </div>

                <div class="mt-4 p-3 bg-light rounded">
                    <h6>Demo Accounts:</h6>
                    <small class="text-muted">
                        <strong>Admin:</strong> admin / admin123<br>
                        <strong>Student:</strong> Register new account
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>