<?php
include '../includes/config.php';
include '../includes/functions.php';

$username = $email = $student_id = '';
$error = '';

if ($_POST) {
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $student_id = sanitize_input($_POST['student_id']);

    if (empty($username) || empty($email) || empty($password) || empty($student_id)) {
        $error = "All fields are required.";
    } elseif (!validate_email($email)) {
        $error = "Invalid email format.";
    } elseif (!validate_student_id($student_id)) {
        $error = "Student ID must be 6-10 alphanumeric characters.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } else {
        try {
            $check_query = "SELECT user_id FROM users WHERE username = :username OR email = :email OR student_id = :student_id";
            $stmt = $db->prepare($check_query);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':student_id', $student_id);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $error = "Username, email, or student ID already exists.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                $insert_query = "INSERT INTO users (username, email, password, student_id, role) 
                                VALUES (:username, :email, :password, :student_id, 'student')";
                $stmt = $db->prepare($insert_query);
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $hashed_password);
                $stmt->bindParam(':student_id', $student_id);

                if ($stmt->execute()) {
                    $_SESSION['success'] = "Registration successful! Please login.";
                    header("Location: login.php");
                    exit();
                } else {
                    $error = "Registration failed. Please try again.";
                }
            }
        } catch (PDOException $exception) {
            $error = "Database error: " . $exception->getMessage();
        }
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0">Student Registration</h4>
            </div>
            <div class="card-body">
                <?php echo display_message($error, 'danger'); ?>
                
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" 
                               value="<?php echo htmlspecialchars($username); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?php echo htmlspecialchars($email); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="student_id" class="form-label">Student ID</label>
                        <input type="text" class="form-control" id="student_id" name="student_id" 
                               value="<?php echo htmlspecialchars($student_id); ?>" 
                               pattern="[A-Z0-9]{6,10}" title="6-10 alphanumeric characters" required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" 
                               minlength="6" required>
                    </div>

                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" 
                               name="confirm_password" minlength="6" required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Register</button>
                    </div>
                </form>

                <div class="text-center mt-3">
                    <p>Already have an account? <a href="login.php">Login here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>