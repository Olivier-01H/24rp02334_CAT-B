<?php
include '../includes/config.php';
include '../includes/functions.php';

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';

// Fetch categories
$categories = [];
try {
    $catStmt = $db->query("SELECT DISTINCT category FROM books ORDER BY category");
    $categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {}

// Build query with filters
$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(title LIKE :q OR author LIKE :q)';
    $params[':q'] = "%$search%";
}
if ($category !== '') {
    $where[] = 'category = :category';
    $params[':category'] = $category;
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

try {
    $sql = "SELECT * FROM books $whereSql ORDER BY created_at DESC";
    $stmt = $db->prepare($sql);
    foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
    $stmt->execute();
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $books = [];
}
?>

<?php include '../includes/header.php'; ?>

<div class="row mb-3">
    <div class="col">
        <h2>Books</h2>
    </div>
    <div class="col-auto">
        <?php if (is_admin()): ?>
            <a class="btn btn-success" href="../admin/books.php">Manage Books</a>
        <?php endif; ?>
    </div>
    <div class="col-12 mt-3">
        <form class="row g-2" method="get" action="">
            <div class="col-md-5">
                <input type="text" class="form-control" name="q" placeholder="Search by title or author" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-4">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category===$cat? 'selected':''; ?>><?php echo htmlspecialchars($cat); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-primary w-100" type="submit">Search</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped align-middle">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($books)): ?>
                        <tr><td colspan="5" class="text-center text-muted">No books found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($books as $b): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($b['title']); ?></td>
                                <td><?php echo htmlspecialchars($b['author']); ?></td>
                                <td><?php echo htmlspecialchars($b['category']); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $b['availability_status']==='available'?'success':'secondary'; ?>">
                                        <?php echo ucfirst($b['availability_status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($b['availability_status']==='available' && is_logged_in()): ?>
                                        <a href="borrow.php?book_id=<?php echo $b['book_id']; ?>" class="btn btn-sm btn-primary">Borrow</a>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-outline-secondary" disabled>Borrow</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

