 <?php
include '../includes/config.php';
include '../includes/auth_check.php';
include '../includes/functions.php';

$book_id = isset($_GET['book_id']) ? intval($_GET['book_id']) : 0;
if ($book_id <= 0) {
    $_SESSION['error'] = 'Invalid book.';
    redirect('../dashboard.php');
}

try {
    // Find an active borrow record
    $stmt = $db->prepare('SELECT id FROM borrowed_books WHERE user_id = :uid AND book_id = :bid AND status = "borrowed" ORDER BY borrow_date DESC LIMIT 1');
    $stmt->execute([':uid' => $_SESSION['user_id'], ':bid' => $book_id]);
    $rec = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$rec) {
        $_SESSION['error'] = 'No active borrow record found.';
        redirect('../dashboard.php');
    }

    $db->beginTransaction();
    $upd1 = $db->prepare('UPDATE borrowed_books SET status = "returned", return_date = NOW() WHERE id = :id');
    $upd1->execute([':id' => $rec['id']]);

    $upd2 = $db->prepare('UPDATE books SET availability_status = "available" WHERE book_id = :bid');
    $upd2->execute([':bid' => $book_id]);

    $db->commit();
    $_SESSION['success'] = 'Book returned successfully.';
    redirect('../dashboard.php');
} catch (PDOException $e) {
    if ($db->inTransaction()) { $db->rollBack(); }
    $_SESSION['error'] = 'Return failed: ' . $e->getMessage();
    redirect('../dashboard.php');
}

