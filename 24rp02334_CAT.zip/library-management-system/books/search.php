 <?php
$q = isset($_GET['q']) ? urlencode($_GET['q']) : '';
$category = isset($_GET['category']) ? urlencode($_GET['category']) : '';
$target = 'index.php';
$sep = '?';
if ($q !== '') { $target .= $sep.'q='.$q; $sep='&'; }
if ($category !== '') { $target .= $sep.'category='.$category; }
header('Location: '.$target);
exit;
?>

