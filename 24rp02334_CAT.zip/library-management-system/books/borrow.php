 <?php
include '../includes/config.php';
include '../includes/auth_check.php';
include '../includes/functions.php';

$book_id = isset($_GET['book_id']) ? intval($_GET['book_id']) : 0;
if ($book_id <= 0) {
    $_SESSION['error'] = 'Invalid book.';
    redirect('index.php');
}

try {
    // Check availability
    $stmt = $db->prepare('SELECT availability_status FROM books WHERE book_id = :id');
    $stmt->bindValue(':id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$book) {
        $_SESSION['error'] = 'Book not found.';
        redirect('index.php');
    }
    if ($book['availability_status'] !== 'available') {
        $_SESSION['error'] = 'Book is not available.';
        redirect('index.php');
    }

    // Begin transaction
    $db->beginTransaction();

    // Insert borrow record (2-week due date)
    $due = (new DateTime('+14 days'))->format('Y-m-d H:i:s');
    $ins = $db->prepare('INSERT INTO borrowed_books (user_id, book_id, due_date, status) VALUES (:uid, :bid, :due, "borrowed")');
    $ins->bindValue(':uid', $_SESSION['user_id'], PDO::PARAM_INT);
    $ins->bindValue(':bid', $book_id, PDO::PARAM_INT);
    $ins->bindValue(':due', $due);
    $ins->execute();

    // Update book status
    $upd = $db->prepare('UPDATE books SET availability_status = "borrowed" WHERE book_id = :id');
    $upd->bindValue(':id', $book_id, PDO::PARAM_INT);
    $upd->execute();

    $db->commit();

    $_SESSION['success'] = 'Book borrowed successfully! Due in 14 days.';
    redirect('index.php');
} catch (PDOException $e) {
    if ($db->inTransaction()) { $db->rollBack(); }
    $_SESSION['error'] = 'Failed to borrow: ' . $e->getMessage();
    redirect('index.php');
}

