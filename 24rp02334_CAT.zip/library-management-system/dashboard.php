<?php
include 'includes/config.php';
include 'includes/auth_check.php';
include 'includes/functions.php';

// Get user's borrowed books
try {
    $borrowed_query = "SELECT b.*, bb.borrow_date, bb.due_date, bb.status 
                      FROM borrowed_books bb 
                      JOIN books b ON bb.book_id = b.book_id 
                      WHERE bb.user_id = :user_id AND bb.status = 'borrowed' 
                      ORDER BY bb.borrow_date DESC";
    $stmt = $db->prepare($borrowed_query);
    $stmt->bindParam(':user_id', $_SESSION['user_id']);
    $stmt->execute();
    $borrowed_books = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $borrowed_books = [];
}

// Get books count
try {
    $books_query = "SELECT COUNT(*) as total_books FROM books WHERE availability_status = 'available'";
    $books_stmt = $db->query($books_query);
    $total_books = $books_stmt->fetch(PDO::FETCH_ASSOC)['total_books'];
} catch (PDOException $e) {
    $total_books = 0;
}
?>

<?php include 'includes/header.php'; ?>

<div class="row">
    <div class="col-12">
        <h2>Dashboard</h2>
        <p class="lead">Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
        
        <?php 
        if (isset($_SESSION['success'])) {
            echo display_message($_SESSION['success'], 'success');
            unset($_SESSION['success']);
        }
        if (isset($_SESSION['error'])) {
            echo display_message($_SESSION['error'], 'danger');
            unset($_SESSION['error']);
        }
        ?>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card dashboard-card success">
            <div class="card-body">
                <h5 class="card-title">Available Books</h5>
                <h2 class="text-success"><?php echo $total_books; ?></h2>
                <p class="card-text">Books ready to borrow</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card dashboard-card warning">
            <div class="card-body">
                <h5 class="card-title">Books Borrowed</h5>
                <h2 class="text-warning"><?php echo count($borrowed_books); ?></h2>
                <p class="card-text">Currently borrowed by you</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card dashboard-card info">
            <div class="card-body">
                <h5 class="card-title">Student ID</h5>
                <h4 class="text-info"><?php echo htmlspecialchars($_SESSION['student_id']); ?></h4>
                <p class="card-text">Your library identifier</p>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2 d-md-flex">
                    <a href="books/index.php" class="btn btn-primary me-2">
                        <i class="fas fa-book"></i> Browse Books
                    </a>
                    <a href="books/search.php" class="btn btn-outline-primary me-2">
                        <i class="fas fa-search"></i> Search Books
                    </a>
                    <?php if (is_admin()): ?>
                        <a href="admin/books.php" class="btn btn-success">
                            <i class="fas fa-cog"></i> Manage Books
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Borrowed Books Section -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">My Borrowed Books</h5>
            </div>
            <div class="card-body">
                <?php if (empty($borrowed_books)): ?>
                    <p class="text-muted">You haven't borrowed any books yet.</p>
                    <a href="books/index.php" class="btn btn-primary">Browse Books</a>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>Borrow Date</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($borrowed_books as $book): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($book['title']); ?></td>
                                        <td><?php echo htmlspecialchars($book['author']); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($book['borrow_date'])); ?></td>
                                        <td>
                                            <?php 
                                            $due_date = strtotime($book['due_date']);
                                            $today = time();
                                            $days_left = round(($due_date - $today) / (60 * 60 * 24));
                                            
                                            if ($days_left < 0) {
                                                echo '<span class="text-danger">' . date('M j, Y', $due_date) . ' (Overdue)</span>';
                                            } elseif ($days_left <= 3) {
                                                echo '<span class="text-warning">' . date('M j, Y', $due_date) . ' (' . $days_left . ' days left)</span>';
                                            } else {
                                                echo date('M j, Y', $due_date);
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $book['status'] === 'borrowed' ? 'warning' : 'success'; ?>">
                                                <?php echo ucfirst($book['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="books/return.php?book_id=<?php echo $book['book_id']; ?>" 
                                               class="btn btn-sm btn-success" 
                                               onclick="return confirm('Are you sure you want to return this book?')">
                                                Return
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>